import sys
import ctypes
class LEDArrayProtocol:
	# WS2812B
	LED_PROTOCOL_WS2812B = 1
	# WS2811_HS
	LED_PROTOCOL_WS2811_HS = 2

	@classmethod
	def getName(self, val):
		if val == self.LED_PROTOCOL_WS2812B:
			return "LED_PROTOCOL_WS2812B"
		if val == self.LED_PROTOCOL_WS2811_HS:
			return "LED_PROTOCOL_WS2811_HS"
		return "<invalid enumeration value>"
