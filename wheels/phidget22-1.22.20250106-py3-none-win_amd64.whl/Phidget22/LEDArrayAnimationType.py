import sys
import ctypes
class LEDArrayAnimationType:
	# Ignore this animation number
	ANIMATION_TYPE_DISABLED = 0
	# Move the pattern in a positively incrementing direction
	ANIMATION_TYPE_FORWARD_SCROLL = 1
	# Move the pattern in a decrementing direction
	ANIMATION_TYPE_REVERSE_SCROLL = 2
	# Randomize LED RGB values based on the specified array
	ANIMATION_TYPE_POPCORN = 3

	@classmethod
	def getName(self, val):
		if val == self.ANIMATION_TYPE_DISABLED:
			return "ANIMATION_TYPE_DISABLED"
		if val == self.ANIMATION_TYPE_FORWARD_SCROLL:
			return "ANIMATION_TYPE_FORWARD_SCROLL"
		if val == self.ANIMATION_TYPE_REVERSE_SCROLL:
			return "ANIMATION_TYPE_REVERSE_SCROLL"
		if val == self.ANIMATION_TYPE_POPCORN:
			return "ANIMATION_TYPE_POPCORN"
		return "<invalid enumeration value>"
